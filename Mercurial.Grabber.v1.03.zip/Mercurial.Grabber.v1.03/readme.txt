Extract to folder first before running.

discord.gg/e8Qy8JKbUK